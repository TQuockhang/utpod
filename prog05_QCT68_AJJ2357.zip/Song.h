#include <cstdlib>
#include <iostream>

#ifndef SONG_H
#define SONG_H
class Song
{
private:
    std::string artist;
    std::string title;
    int size;

public:
    Song();
    Song(std::string insertArtist, std::string insertTitle, int insertsize);

    void setTitle(std::string);
    void setArtist(std::string);
    void setSize(int);

    std::string getTitle() const
        {return title;}

    std::string getArtist() const
        {return artist;}

    int getSize() const
        {return size;}

    bool operator == (Song const &rhs);

    bool operator > (Song const &rhs);

    bool operator < (Song const &rhs);

    bool operator <= (Song const &rhs);

    bool operator >= (Song const &rhs);

  };
std::ostream& operator << (std::ostream& out, const Song &s);


#endif
